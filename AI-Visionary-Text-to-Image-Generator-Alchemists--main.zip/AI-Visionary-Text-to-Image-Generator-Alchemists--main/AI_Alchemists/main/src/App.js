import './App.css';
import ImageGenerationForm from './components/Text2Image';

function App() {
  return (
    <div className="App">
      <ImageGenerationForm />
    </div>
  );
}

export default App;